package com.example.groceryshoppinglist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class listCloseup extends AppCompatActivity {

    private ItemViewModel mItemViewModel;
    public static final int NEW_ITEM_ACTIVITY_REQUEST_CODE = 1;
    private TextView itemItemView;
    private TextView itemCategory;


    public void addNewItem(View view){
        //get values from input
        Intent intent = getIntent();
        String name = intent.getStringExtra("ownerEmail");
        int listID = intent.getIntExtra("listID", 0);
        String currentUser = intent.getStringExtra("currentUser");

        Intent newItem = new Intent(this, addNewItem.class);
        newItem.putExtra("userName", name);
        newItem.putExtra("listID", listID);
        newItem.putExtra("currentUser", currentUser);

        startActivityForResult(newItem, NEW_ITEM_ACTIVITY_REQUEST_CODE);
    }


    public void backBtn(View view){
        //get values from input
        Intent intent = getIntent();
        String currentUser = intent.getStringExtra("currentUser");

        Intent backBtn = new Intent(this, Overview.class);
        backBtn.putExtra("username", currentUser);

        startActivity(backBtn);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_closeup);

        //get values from input
        Intent intent = getIntent();
        String name = intent.getStringExtra("ownerEmail");
        int listID = intent.getIntExtra("listID", 0);
        int itemID = intent.getIntExtra("itemID", 0);
        String currentUser = intent.getStringExtra("currentUser");

        System.out.println(name);

        if(name != null) {
            TextView ownerName = (TextView) findViewById(R.id.listownerName2);
            ownerName.setText(String.valueOf(name));
        } else {
            String name1 = intent.getStringExtra("username");
            TextView ownerName = (TextView) findViewById(R.id.listownerName2);
            ownerName.setText(String.valueOf(name1));
        }


        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        final ItemListAdapter adapter = new ItemListAdapter(new ItemListAdapter.ItemDiff(), name, currentUser);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        ItemViewModelFactory factory = new ItemViewModelFactory(this.getApplication(), listID);
        mItemViewModel = new ViewModelProvider(this, factory).get(ItemViewModel.class);


        mItemViewModel.getItemsByListID(listID).observe(this, items -> {
            //Update the cached copy of the items in the adapter.
            adapter.submitList(items);
        });


        if(itemID != 0){
            mItemViewModel.updateIsChecked(true, itemID);
        }

    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        //change listID here
        if (requestCode == NEW_ITEM_ACTIVITY_REQUEST_CODE && resultCode == RESULT_OK) {
            Item item = new Item(0, data.getStringExtra("item"), data.getStringExtra("quantity"), data.getIntExtra("listIDFromAdd", 0), data.getStringExtra("category"), false);
            mItemViewModel.insert(item);
        } else {
            Toast.makeText(
                    getApplicationContext(),
                    R.string.empty_not_saved,
                    Toast.LENGTH_LONG).show();
        }
    }
}